$(document).ready(function() {
    var dt_table = $('.datatable').dataTable({
        language: dt_language,  // global variable defined in html
        order: [[ 1, "desc" ]],
        lengthMenu: [[2, 5], [2, 5]],
        columns: [
            {
                data: 'imgpath',
                "width": "200px",
                 render: function (data, type, row, meta) {                                               
                     return "<img src='" + data + "' />";
                      //还可以给图片加上超链接
                     //return "<a href='" + data + "'>" + data + "</a>";
                }
            },
            {
                data: 'username',
                orderable: true,
                searchable: true,
                className: "center"
            },
            {
                data: 'password',
                orderable: true,
                searchable: true,
                className: "center"
            },

        ],
        searching: false,
        processing: true,
        serverSide: true,
        stateSave: false,
        ajax: {
            "url": USERS_LIST_JSON_URL,
            "data": function(d){
                return $.extend( {}, d, {
                    //"de_id"  : document.getElementById('de_id').value,
                    "de_id"  : '123'
                });
            }
        }
    });
});